function addLocalVideo() {
    Twilio.Video.createLocalVideoTrack().then(track => {
        let video = document.getElementById('local').firstChild;
        video.appendChild(track.attach());
    });
};

// add joining and diconnecting

let connected = false;
const usernameInput = document.getElementById('username');
const button = document.getElementById('join_leave');
const container = document.getElementById('container');
const count = document.getElementById('count');
const root = document.getElementById('root');
const toggleChat = document.getElementById('toggle_chat');
const chatScroll = document.getElementById('chat-scroll');
const chatContent = document.getElementById('chat-content');
const chatInput = document.getElementById('chat-input');
let chat;
var conv;
let room;
let participantid;

addLocalVideo();
button.addEventListener('click', connectButtonHandler);

function connectButtonHandler(event) {
    event.preventDefault();
    if (!connected) {
        let username = usernameInput.value;
        if (!username) {
            alert('Enter your name before connecting');
            return;
        }
        button.disabled = true;
        button.innerHTML = 'Connecting...';
        connect(username).then((result) => {
            

            button.innerHTML = 'Leave call';
            button.disabled = false;
        }).catch((error) => {
            console.log(error,"err")
            button.innerHTML = 'Join call';
            button.disabled = false;    
        });
    }
    else {
        disconnect();
        button.innerHTML = 'Join call';
        connected = false;
    }
};
function connect(username) {
    let promise = new Promise((resolve, reject) => {
        // get a token from the back end
        let data;
        axios.post('http://localhost:5000/api/video/token', {
            username: username
          })
        .then(res => res).then(_data => {
                
            // join video call
            data = _data;
            window.localStorage.setItem("id",data.data.participantid)
            return Twilio.Video.connect(data.data.token);
        }).then(_room => {
            room = _room;
            room.participants.forEach(participantConnected);
            room.on('participantConnected', participantConnected);
            room.on('participantDisconnected', participantDisconnected);
            connected = true;
            updateParticipantCount();
            
            connectChat(data.data.token, data.data.service_sid);
            resolve();
        }).catch((err) => {
            console.log (err,"Err2")
            reject();
        });
    });
    return promise;
};



function updateParticipantCount() {
    if (!connected)
        count.innerHTML = 'Disconnected.';
    else
        count.innerHTML = (room.participants.size + 1) + ' participants online.';
};




function participantConnected(participant) {
    
    let participantDiv = document.createElement('div');
    participantDiv.setAttribute('id', participant.sid);
    participantid= participant.sid
    participantDiv.setAttribute('class', 'participant');

    let tracksDiv = document.createElement('div');
    participantDiv.appendChild(tracksDiv);

    let labelDiv = document.createElement('div');
    labelDiv.innerHTML = participant.identity;
    participantDiv.appendChild(labelDiv);

    container.appendChild(participantDiv);

    participant.tracks.forEach(publication => {
        if (publication.isSubscribed)
            trackSubscribed(tracksDiv, publication.track);
    });
    participant.on('trackSubscribed', track => trackSubscribed(tracksDiv, track));
    participant.on('trackUnsubscribed', trackUnsubscribed);

    updateParticipantCount();
};

function participantDisconnected(participant) {
    participant.on()
    document.getElementById(participant.sid).remove();


    updateParticipantCount();
};

function trackSubscribed(div, track) {
    div.appendChild(track.attach());
};

function trackUnsubscribed(track) {
    track.detach().forEach(element => element.remove());
};


function disconnect() {
    room.disconnect();
        console.log(chat, "chat=====")
        axios.post('http://localhost:5000/api/chat/userdelete', {
            participantid: window.localStorage.getItem("id"),
            conversationid:conv.sid
          })
        .then(res =>{
            if(res.status_code === 200){
                window.localStorage.removeItem("id")
            }
        })
    while (container.lastChild.id != 'local')
        container.removeChild(container.lastChild);
        if (root.classList.contains('withChat')) {
            root.classList.remove('withChat');
        }
        toggleChat.disabled = true;
    button.innerHTML = 'Join call';
    connected = false;
    updateParticipantCount();
};


//chat function 


function connectChat(token, conversationSid) {



    console.log(conversationSid,"conversationSid")
    return Twilio.Conversations.Client.create(token).then(chat => {
        chat = chat;
console.log(chat,"chat")


        return chat.getConversationBySid(conversationSid).then((_conv) => {
            conv = _conv;
            console.log(conv, "conv===")
            conv.on('messageAdded', (message) => {
                console.log(message,"message")
                addMessageToChat(message.author, message.body);
            });
            return conv.getMessages().then((messages) => {
                console.log(messages,"getmessages")
                chatContent.innerHTML = '';
                for (let i = 0; i < messages.items.length; i++) {
                    addMessageToChat(messages.items[i].author, messages.items[i].body);
                }
                toggleChat.disabled = false;
            });
        }).catch((e)=>console.log(e))
    }).catch(e => {
        console.log(e);
    });
};
function addMessageToChat(user, message) {
    console.log(user,"user")
    console.log(message,"message add")
    chatContent.innerHTML += `<p><b>${user}</b>: ${message}`;
    chatScroll.scrollTop = chatScroll.scrollHeight;
    
}
function toggleChatHandler() {
    event.preventDefault();
    if (root.classList.contains('withChat')) {
        root.classList.remove('withChat');
    }
    else {
        root.classList.add('withChat');
        chatScroll.scrollTop = chatScroll.scrollHeight;
    }
};

toggleChat.addEventListener('click', toggleChatHandler);

function onChatInputKey(ev) {
    if (ev.keyCode == 13) {
        console.log(conv)
        conv.sendMessage(chatInput.value);
        chatInput.value = '';
    }
};


chatInput.addEventListener('keyup', onChatInputKey);